# gartic.io-bot
[Bot Site](https://anonimbiri.github.io/gartic.io-bot/)



-----------------------
# Installation
## Requirements 
| Tampermonkey  | [Download](https://www.tampermonkey.net) |
| ----------- | ------- |

| Script        | [Download](https://github.com/anonimbiri/gartic.io-bot/raw/main/script/Gartic%20bot%20control.user.js) |
| ----------- | ------- |

## Installation Guide
**it's pretty simple to install**\
\
**Press the `download` button that appears on the screen.**\
\
**Congratulations, you downloaded**

    


-----------------------
## Disclaimer 
This project is for Educational Use only. We do not condone this software being used to gain an advantage against other people.
